﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataTable_Demo.Controllers
{
    class jsonMessage
    {
        public string Message { get; set; }
        public string MessageList { get; set; }
        public bool Status { get; set; }
    }
}
