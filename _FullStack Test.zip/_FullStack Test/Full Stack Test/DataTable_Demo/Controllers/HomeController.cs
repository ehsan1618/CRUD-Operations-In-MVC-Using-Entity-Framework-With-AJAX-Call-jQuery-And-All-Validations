﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;

namespace DataTable_Demo.Controllers
{

    /// <summary>
    /// Full Stack Test
    /// Ehsan Ullah Khan
    /// ehsan1618@gmail.com
    /// </summary>
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        private PMSEntities context = new PMSEntities();

        public ActionResult Index()
        {
            return View();
        }
        public JsonResult SaveAndUpdateRecord(int PID, string FirstName, string LastName, string Email)
        {
            Thread.Sleep(1500);
            var result = new jsonMessage();
            try
            {
                //define the model
                MockData ObjMockData = new MockData();                
                ObjMockData.FirstName = FirstName;
                ObjMockData.LastName = LastName;
                ObjMockData.Email = Email;


                if (!string.IsNullOrEmpty(FirstName) && (!string.IsNullOrEmpty(LastName) && (!string.IsNullOrEmpty(Email))))
                {
                    //for insert recored..
                    if (PID == 0)
                    {
                        context.MockDatas.Add(ObjMockData);
                        result.Message = "your record has been saved success..";
                        result.Status = true;
                    }
                    else  //for update recored..
                    {
                        ObjMockData.ID = PID;
                        context.Entry(ObjMockData).State = EntityState.Modified;
                        result.Message = "your record has been updated successfully..";
                        result.Status = true;
                    }
                    context.SaveChanges();

                }
                else
                {
                    result.Message = "Please fill all the required fields..";
                    result.Status = false;
                }           


            }
            catch (Exception ex)
            {
                ErrorLogers.ErrorLog(ex);
                result.Message = "We are unable to process your request at this time. Please try again later.";
                result.Status = false;
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetRecords()
        {
            Thread.Sleep(1000);

            List<MockData> _list = new List<MockData>();

            try
            {
                _list = context.MockDatas.ToList();
                var result = from c in _list
                             select new[]
                             {
                          Convert.ToString( c.ID ),  // 0   
                          Convert.ToString( c.FirstName ),  // 1   
                          Convert.ToString( c.LastName ),  // 2   
                          Convert.ToString( c.Email ),  // 3   
                                                   };

                return Json(new
                {
                    aaData = result
                }, JsonRequestBehavior.AllowGet);
            }

            catch (Exception ex)
            {
                ErrorLogers.ErrorLog(ex);
                return Json(new
                {
                    aaData = new List<string[]> { }
                }, JsonRequestBehavior.AllowGet);
            }

        }

        public JsonResult DeleteRecord(int id)
        {
            Thread.Sleep(1500);
            var result = new jsonMessage();
            try
            {

                var Record = new MockData { ID = id };
                context.Entry(Record).State = EntityState.Deleted;
                context.SaveChanges();


                result.Message = "your record has been deleted successfully..";
                result.Status = true;

            }
            catch (Exception ex)
            {
                ErrorLogers.ErrorLog(ex);
                result.Message = "We are unable to process your request at this time. Please try again later.";
                result.Status = false;
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }

    }
}
